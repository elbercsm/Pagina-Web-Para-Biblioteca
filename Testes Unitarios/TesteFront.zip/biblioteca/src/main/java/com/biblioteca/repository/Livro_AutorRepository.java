package com.biblioteca.repository;

public class Livro_AutorRepository {

}
