package com.biblioteca.repository;

public class JDBCSinkException extends Exception {

}
