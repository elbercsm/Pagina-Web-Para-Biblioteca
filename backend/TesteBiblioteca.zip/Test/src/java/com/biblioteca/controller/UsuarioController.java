package com.biblioteca.controller;

import java.util.ArrayList;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.biblioteca.model.UsuarioModel;
import com.biblioteca.repository.UsuariosRepository;

public class UsuarioController {

	@RequestMapping(method = RequestMethod.GET, value = "/usuario")
	public ArrayList<UsuarioModel> getUsuarios() {
		return UsuariosRepository.charge();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/usuario", consumes = MediaType.ALL_VALUE)
	public void postUsuario(@RequestBody UsuarioModel usuario) {
		UsuariosRepository.insert(usuario);
	}

}
