package com.biblioteca.controller;

import static com.biblioteca.generatedclasses.tables.Perfil.PERFIL;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import org.jooq.DSLContext;
import org.jooq.Record;
import org.jooq.Result;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.biblioteca.model.LivroModel;
import com.biblioteca.model.PerfilModel;
import com.biblioteca.repository.LivrosRepository;
import com.biblioteca.repository.PerfisRepository;

@RestController
public class PerfilController {
	
	@RequestMapping(method = RequestMethod.GET,value = "/perfil")
	public ArrayList<PerfilModel> getUsuarios() {
		return PerfisRepository.getUsuarios();
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "/perfil/prioridades")
	public ArrayList<String> getPropriedades() {
		return PerfisRepository.Prioridades();
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "/perfil/valores")
	public ArrayList<String> getValores() {
		return PerfisRepository.Valores();
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "/perfil" , consumes=MediaType.ALL_VALUE)
	public String postLivros(@RequestBody PerfilModel perfil) {
		 return PerfisRepository.insert(perfil);
	}
	
	@RequestMapping(method = RequestMethod.PUT,value = "/perfil" , consumes=MediaType.ALL_VALUE)
	public void atualizar(@RequestBody PerfilModel perfil) {
		PerfisRepository.atualizar(perfil);
	}
	
	@RequestMapping(method = RequestMethod.DELETE,value = "/perfil" , consumes=MediaType.ALL_VALUE)
	public void deletar(@RequestBody int id) {
		System.out.println("Delete");
		PerfisRepository.deletar(id);
	}
}
