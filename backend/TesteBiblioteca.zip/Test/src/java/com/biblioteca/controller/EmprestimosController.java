package com.biblioteca.controller;

import java.util.ArrayList;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.biblioteca.model.EmprestimoModel;
import com.biblioteca.repository.EmprestimosRepository;


public class EmprestimosController {
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/emprestimo")
	public ArrayList<EmprestimoModel> getEmpresimos() {
		return EmprestimosRepository.charge();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/emprestimo", consumes = MediaType.ALL_VALUE)
	public void postEMprestimo(@RequestBody EmprestimoModel emprestimo) {
		EmprestimosRepository.insert(emprestimo);
	}

}
