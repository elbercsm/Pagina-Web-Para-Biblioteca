package com.biblioteca.repository;

import static com.biblioteca.generatedclasses.tables.Usuario.USUARIO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import org.jooq.DSLContext;
import org.jooq.Record;
import org.jooq.Result;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import com.biblioteca.generatedclasses.tables.Usuario;
import com.biblioteca.model.UsuarioModel;

public class UsuariosRepository {
	static Connection conn = null;

	static String userName = "root";
	static String passWord = "";
	static String url = "jdbc:mysql://localhost:3306/bibliotecaPO";

	public static ArrayList<UsuarioModel> charge() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, userName, passWord);
			DSLContext create = DSL.using(conn, SQLDialect.MYSQL);

			Result<Record> result = create.select().from(USUARIO).fetch();

			ArrayList<UsuarioModel> allUsuarios = new ArrayList<UsuarioModel>();

			// iterando os resultados
			for (Record r : result) {
				UsuarioModel usuario = new UsuarioModel();

				usuario.setId(r.getValue(USUARIO.ID));
				usuario.setUsuario(r.getValue(USUARIO.USUARIO_));
				usuario.setEmail(r.getValue(USUARIO.EMAIL));
				usuario.setSenha(r.getValue(USUARIO.SENHA));
				usuario.setTelefone(r.getValue(USUARIO.TELEFONE));
				usuario.setFoto(r.getValue(USUARIO.FOTO));
				usuario.setStatus_usuario(r.getValue(USUARIO.STATUS_USUARIO) != null);
				usuario.setFk_peril(r.getValue(USUARIO.FK_PERFIL));

				allUsuarios.add(usuario);

			}
			return allUsuarios;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return null;
	}

	public static void insert(UsuarioModel usuario) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, userName, passWord);
			DSLContext create = DSL.using(conn, SQLDialect.MYSQL);

			Result<Record> result = create.select().from(USUARIO).fetch();

			create.insertInto(USUARIO, USUARIO.USUARIO_, USUARIO.SENHA, USUARIO.EMAIL, USUARIO.TELEFONE, USUARIO.FOTO,
					 USUARIO.FK_PERFIL)
					.values(usuario.getUsuario(), usuario.getSenha(), usuario.getEmail(), usuario.getTelefone(),
							usuario.getFoto(), usuario.getFk_peril())
					.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException ignore) {
				}
			}
		}

	}
}
